#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <time.h>

int s; /* socket */

void
finalizar (int senyal)
{
	printf("Recibida la señal de fin (cntr-C)\n\r");
	close(s); /* cerrar para que accept termine con un error y salir del bucle principal */
}

int
main (int argc, char *argv[])
{
	//Variables nuevas
	char *servidor_puerto;
	char *directorio_raiz = "/home/";
	char *fichero_configuracion;
	char *indice="index.html";
	FILE *config;
	FILE *recurso;
	int clientesMax=4;
	int tengoRoot = 0;
	int tengoIndex = 0;
	//Variables para el tiempo
	time_t rawtime;
	struct tm * timeinfo;
	char buffer [80];
	//Variables esqueleto cliente-servidor
	char mensaje[1024], respuesta[]="Gracias por tu mensaje";
	struct sockaddr_in dir_servidor, dir_cliente;
	unsigned int long_dir_cliente;
	int s2;
	int n, enviados, recibidos;
	int proceso;


	/* Tomar los argumentos */
	int puerto=0;
	if(argc != 1){
		puerto = atoi(argv[1]);
	}
	if(puerto !=0)
	{
		//Llega puerto en el argumento 1
		servidor_puerto = argv[1];
		if(argc>3){
			if(strcmp(argv[2], "") != 0){
				if(strcmp(argv[2],"-d") == 0){
					directorio_raiz = argv[3];
					tengoRoot = 1;
				}else{
					if(strcmp(argv[2],"-c") == 0){
						tengoIndex=1;
						fichero_configuracion = argv[3];
					}
				}
				if(argc>4){
					if(strcmp(argv[4],"-c") == 0){
						fichero_configuracion = argv[5];
						tengoIndex=1;
					}else{
						if(strcmp(argv[4],"-d")==0){
							tengoRoot = 1;
							directorio_raiz = argv[5];
						}
					}
				}
			}
		}

	}else{
		//No llega puerto
		servidor_puerto = "6000";
		if(argc>2){
			if(strcmp(argv[1],"-d") == 0){
				directorio_raiz = argv[2];
				tengoRoot = 1;
			}else{
				if(strcmp(argv[1],"-c")==0){
					tengoIndex=1;
					fichero_configuracion = argv[2];
				}
			}
			if(argc>3){
				if(strcmp(argv[3],"-d") == 0){
					directorio_raiz = argv[4];

					tengoRoot = 1;
				}else{
					if(strcmp(argv[3],"-c")==0){
						tengoIndex=1;
						fichero_configuracion = argv[4];
					}
				}
			}
		}
	}
	char configuracion2[100];
	char maxclients[100];
	char index[100];
	config = fopen(fichero_configuracion, "r");
	if(config){
		fgets(configuracion2,100,config);
		fgets(maxclients,100,config);
		fgets(index,100,config);

		char *token;
  	char *search = ":";

  	// Token apunta a "documentRoot".
  	token = strtok(configuracion2, search);

  	if(strcmp(token,"documentRoot")==0){
   		//Token apunta a la ruta

   		token = strtok(NULL, search);

			if(tengoRoot == 0){
				directorio_raiz = token;
   			strtok(directorio_raiz, "\n");

			}
  	}else{
   		fprintf(stderr, "Error. Fichero de configuración mal formateado.\r\n");
  	}

		token = strtok(maxclients, search);
		if(strcmp(token,"MaxClients")==0){
   		//Token apunta a la ruta
   		token = strtok(NULL, search);
			clientesMax = atoi(token);
  	}else{
   		fprintf(stderr, "Error. Fichero de configuración mal formateado.\r\n");
  	}

		token = strtok(index, search);
		if(strcmp(token,"DirectoryIndex")==0){
   		//Token apunta a la ruta
   		token = strtok(NULL, search);
			if(tengoIndex==0){
				indice = token;
			}
  	}else{
   		fprintf(stderr, "Error. Fichero de configuración mal formateado.\r\n");
  	}
		printf("Mostrando datos de configuración ......");
		printf("\nDirectorio => %s\nClientes máximos => %d\nIndex => %s\n\n",directorio_raiz,clientesMax,indice);
		fclose(config);
	}
	/**** Paso 1: Abrir el socket ****/

	s = socket(AF_INET, SOCK_STREAM, 0); /* creo el socket */
	if (s == -1)
	{
		fprintf(stderr, "Error. No se puede abrir el socket\n\r");
		return 1;
	}
	printf("Socket abierto\n\r");

	/**** Paso 2: Establecer la dirección (puerto) de escucha ****/

	dir_servidor.sin_family = AF_INET;
	dir_servidor.sin_port = htons(atoi(servidor_puerto));
	dir_servidor.sin_addr.s_addr = INADDR_ANY; /* cualquier IP del servidor */
	if (bind(s, (struct sockaddr *)&dir_servidor, sizeof(dir_servidor)) == -1)
	{
		fprintf(stderr, "Error. No se puede asociar el puerto al servidor\n\r");
		close(s);
		return 1;
	}
	printf("Puerto de escucha establecido\n\r");

	/**** Paso 3: Preparar el servidor para escuchar ****/

	if (listen(s, clientesMax) == -1)
	{
		fprintf(stderr, "Error preparando servidor\n\r");
		close(s);
		return 1;
	}
	printf("Socket preparado\n\r");

	/**** Paso 4: Esperar conexiones ****/

	signal(SIGINT, finalizar);

	while (1)
	{
		fprintf(stderr, "Esperando conexión en el puerto %s...\n\r", servidor_puerto);
		long_dir_cliente = sizeof (dir_cliente);
		s2 = accept (s, (struct sockaddr *)&dir_cliente, &long_dir_cliente);
		/* s2 es el socket para comunicarse con el cliente */
		/* s puede seguir siendo usado para comunicarse con otros clientes */
		if (s2 == -1)
		{
			break; /* salir del bucle */
		}
		/* crear un nuevo proceso para que se pueda atender varias peticiones en paralelo */
		proceso = fork();
		if (proceso == -1) exit(1);
		if (proceso == 0) /* soy el hijo */
		{
			close(s); /* el hijo no necesita el socket general */

			/**** Paso 5: Leer el mensaje ****/

			n = sizeof(mensaje);
			recibidos = read(s2, mensaje, n);
			if (recibidos == -1)
			{
				fprintf(stderr, "Error leyendo el mensaje\n\r");
				exit(1);
			}
			mensaje[recibidos] = '\0'; /* pongo el final de cadena */
			printf("Mensaje [%d]: %s\n\r", recibidos, mensaje);
			//Variables para ejecutar la respuesta
			char *token;
			char *search = " ";
			char *respuesta;
			char *peticion;
			char aux_mensaje[1024];
			int size_recurso;
			char servir[10000];
			strcpy(aux_mensaje,mensaje);

			//Token apunta al metodo EJ:"GET"
			token = strtok(aux_mensaje, search);

			peticion = token;
			//Token apunta al recurso
			token = strtok(NULL, search);
			//Para guardarnos el tamaño en bits del archivo solicitado
			char tamano[50];
			//Para guardar el contenido del fichero
			char *archivo = 0;
			//Para obtener la hora del ordenador
			time (&rawtime);

    	timeinfo = localtime (&rawtime);
    	strftime (buffer,80,"%a, %e %b %Y %T GMT",timeinfo);

			//Guardar la ruta del fichero. Si token = "/" no hay recurso.
			//Entonces enviaremos el recurso por defecto "indice"
			if(strcmp(token,"/")==0){
				strcat(directorio_raiz,indice);
			}else{
				strcat(directorio_raiz,token);
			}
			//Llega GET

			if(strcmp(peticion,"GET")==0){
				//Intentamos abrir el archivo para ver si existe.
				recurso = fopen(directorio_raiz,"rb");
				if(recurso){
					respuesta = "200 OK";

					fseek(recurso, 0L, SEEK_END);//Movemos a final de fichero
					size_recurso = ftell(recurso);//Guardamos el tamaño del recurso en bits
					sprintf(tamano, "%d", size_recurso);//Convertimos el tamaño de int a char
					fseek(recurso, 0L, SEEK_SET);//Movemos a principio de fichero
					archivo = malloc(size_recurso);//Reservamos memoria en el buffer para el fichero
					if(archivo){
            //Leemos
						fread(archivo, 1, size_recurso, recurso);
					}
					fclose(recurso);
				}else{
					respuesta = "404 Not Found";
				}
				strcpy(servir,"HTTP/1.1 ");
				strcat(servir,respuesta);
				strcat(servir,"\r\n");
				strcat(servir,"Date: ");
				strcat(servir,buffer);
				strcat(servir,"\r\n");
				strcat(servir,"Server: Mariantonia.");
				strcat(servir,"\r\n");
				strcat(servir,"Accept-Ranges: bytes");
				strcat(servir,"\r\n");
				strcat(servir,"Content-Length: ");
				strcat(servir,tamano);
				strcat(servir,"\r\n");
				strcat(servir,"Content-type: text/html");
				strcat(servir,"\r\n");
				strcat(servir,"\r\n");

				if(archivo){//Si existe el archivo entregamos el recurso
					strcat(servir, archivo);
				}else{//Si no existe error 404
					strcat(servir,"<html><h1>Archivo ");
					strcat(servir,token);
					strcat(servir," no encontrado en el servidor (Error 404)</h1></html>");
				}

			}else if(strcmp(peticion,"PUT")==0){
        recurso = fopen(directorio_raiz,"w");

				if(recurso){
					respuesta = "201 CREATED";
					char *puntero=strstr(mensaje,"\\n\\n");
					int i=4;
					char puntero2[strlen(puntero)-3];
					for(i=4;i<strlen(puntero);i++){
						puntero2[i-4]=puntero[i];
					}

					strcat(puntero2,"\0");
					fputs(puntero2,recurso);
					fclose(recurso);
				}else{
					respuesta="403 FORBIDDEN";
				}
				strcpy(servir,"HTTP/1.1 ");
				strcat(servir,respuesta);
				strcat(servir,"\r\n");
				strcat(servir,"Date: ");
				strcat(servir,buffer);
				strcat(servir,"\r\n");
				strcat(servir,"Server: Mariantonia.");
				strcat(servir,"\r\n");
				strcat(servir,"Accept-Ranges: bytes");
				strcat(servir,"\r\n");
				strcat(servir,"Content-type: text/html");
				strcat(servir,"\r\n");
				strcat(servir,"\r\n");


				strcat(servir,"<html><h1>");
				if(strcmp(respuesta,"201 CREATED")==0){
					strcat(servir,"Archivo creado</h1></html>");
				}else{
					strcat(servir,"Error 403 Acceso denegado</h1></html>");
				}

			}else if(strcmp(peticion,"HEAD")==0){
				recurso = fopen(directorio_raiz,"rb");
				if(recurso){
					respuesta = "200 OK";
					printf("Entra");
					fseek(recurso, 0L, SEEK_END);//Movemos a final de fichero
					size_recurso = ftell(recurso);//Guardamos el tamaño del recurso en bits
					sprintf(tamano, "%d", size_recurso);//Convertimos el tamaño de int a char
					fseek(recurso, 0L, SEEK_SET);//Movemos a principio de fichero
					//archivo = malloc(size_recurso);//Reservamos memoria en el buffer para el fichero
					fclose(recurso);
				}else{
					respuesta = "404 Not Found";
				}
				strcpy(servir,"HTTP/1.1 ");
				strcat(servir,respuesta);
				strcat(servir,"\r\n");
				strcat(servir,"Date: ");
				strcat(servir,buffer);
				strcat(servir,"\r\n");
				strcat(servir,"Server: Mariantonia.");
				strcat(servir,"\r\n");
				strcat(servir,"Accept-Ranges: bytes");
				strcat(servir,"\r\n");
				strcat(servir,"Content-Length: ");
				strcat(servir,tamano);
				strcat(servir,"\r\n");
				strcat(servir,"Content-type: text/html");

				if(strcmp(respuesta,"404 Not Found")==0){
					strcat(servir,"<html><h1>Archivo ");
					strcat(servir,token);
					strcat(servir," no encontrado en el servidor (Error 404)</h1></html>");
				}

			}else if(strcmp(peticion,"DELETE")==0){
				printf("Entra");
				int cant_delete=0;
        //Comprobamos que se pide el fichero
          recurso = fopen(directorio_raiz,"rb");
          if(recurso){
						fseek(recurso, 0L, SEEK_END); //Movemos a final de fichero
						size_recurso = ftell(recurso);//Guardamos el tamaño del recurso en bits
						sprintf(tamano, "%d", size_recurso);//Convertimos el tamaño de int a char
						fseek(recurso, 0L, SEEK_SET);//Movemos a principio de fichero
						if(remove(directorio_raiz)==0){
              respuesta="200 OK";
            }else{
              respuesta="403 forbidden";
							cant_delete=1;
            }
					}else{
						respuesta="404 Not Found";
					}
						strcpy(servir,"HTTP/1.1 ");
						strcat(servir,respuesta);
						strcat(servir,"\r\n");
						strcat(servir,"Date: ");
						strcat(servir,buffer);
						strcat(servir,"\r\n");
						strcat(servir,"Server: Mariantonia.");
						strcat(servir,"\r\n");
						strcat(servir,"Content-Length: ");
						strcat(servir,tamano);
						strcat(servir,"\r\n");
						strcat(servir,"Content-type: text/html");
						strcat(servir,"\r\n");
						if(recurso==NULL){
							strcat(servir,"<html><h1>Archivo ");
							strcat(servir,token);
							strcat(servir," no encontrado en el servidor (Error 404)</h1></html>");
						}else{
							fclose(recurso);
						}
						if(cant_delete==1){
							strcat(servir,"<html><h1>Petición denegada (Error 403)</h1></html>");
						}


			}else{
				//PETICION ERRONEA
        printf("\n\nPETICIÓN ERRÓNEA\n\n");
        strcat(servir,"Error 400 Bad request");
			}

			/**** Paso 6: Enviar respuesta ****/

			n = strlen(servir);
			printf("Enviar respuesta [%d bytes]: %s\n\r", n, servir);
			enviados = write(s2, servir, n);
			if (enviados == -1 || enviados < n)
			{
				fprintf(stderr, "Error enviando la respuesta (%d)\n\r",enviados);
				close(s);
				return 1;
			}

			printf("Respuesta enviada\n\r");

			close(s2);
			exit(0); /* el hijo ya no tiene que hacer nada */
		}
		else /* soy el padre */
		{
			close(s2); /* el padre no usa esta conexión */
		}

	}

	/**** Paso 7: Cerrar el socket ****/
	close(s);
	printf("Socket cerrado\n\r");
	return 0;
}
